"use strict";
(() => {
var exports = {};
exports.id = 729;
exports.ids = [729];
exports.modules = {

/***/ 3041:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddCircleRounded");

/***/ }),

/***/ 2832:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LogoutRounded");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 9791:
/***/ ((module) => {

module.exports = require("mdi-material-ui");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1223:
/***/ ((module) => {

module.exports = require("react-loader-spinner");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [827,763], () => (__webpack_exec__(763)));
module.exports = __webpack_exports__;

})();